function validateForm(event) {
  // Write your javascript validation code here
}
